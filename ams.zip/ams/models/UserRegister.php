<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user_register".
 *
 * @property int $user_id
 * @property string $username
 * @property string $password
 * @property string $status
 * @property string $role
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class UserRegister extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user_register';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password', 'status', 'role'], 'required'],
            [['created_date', 'updated_date'], 'safe'],
            [['username', 'password', 'status', 'role'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'user_id' => 'User ID',
            'username' => 'Username',
            'password' => 'Password',
            'status' => 'Status',
            'role' => 'Role',
            'created_date' => 'Created Date',
            'updated_date' => 'Updated Date',
        ];
    }
}

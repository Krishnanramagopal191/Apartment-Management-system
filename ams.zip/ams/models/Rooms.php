<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rooms".
 *
 * @property int $room_id
 * @property int|null $room_no
 * @property string|null $room_status
 * @property string|null $room_type
 * @property string|null $room_occupied_by
 * @property string|null $owner_name
 */
class Rooms extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'rooms';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room_no', 'no_of_residents'], 'integer'],
            [['room_status', 'room_type', 'room_occupied_by', 'user_name'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'room_id' => 'Room ID',
            'room_no' => 'Room No',
            'room_status' => 'Room Status',
            'room_type' => 'Room Type',
            'room_occupied_by' => 'Room Occupied By',
            'user_name' => 'User Name',
            'no_of_residents' => 'No of Residents',
        ];
    }
}
